<?php include 'header.php'; ?>
<div class="success-message">
    <h2>Registration Successful!</h2>
    <p>Thank you for registering. Your account has been created.</p>
    <a href="login.php" class="btn">Proceed to Login</a>
</div>
<?php include 'footer.php'; ?>